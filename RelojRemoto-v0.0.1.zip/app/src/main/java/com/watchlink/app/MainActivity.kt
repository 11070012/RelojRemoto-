package com.watchlink.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowInsets
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.hypot
import kotlin.math.min

class MainActivity : Activity() {

    private val bg = 0xFF0B0D14.toInt()
    private val reqPickApk = 21
    private val main = Handler(Looper.getMainLooper())

    private lateinit var prefs: SharedPreferences
    private lateinit var screenImg: ImageView
    private lateinit var overlay: TextView
    private lateinit var statusTv: TextView
    private lateinit var liveBtn: Button

    private var live = false
    private var failures = 0
    private var bmp: Bitmap? = null

    private var downX = 0f
    private var downY = 0f
    private var downT = 0L

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("relojremoto", Context.MODE_PRIVATE)
        AdbSession.init(this)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        AdbSession.onStatus = { runOnUiThread { updateStatus() } }
        updateStatus()

        // Reconexión automática si ya habías conectado alguna vez.
        if (!prefs.getString("host", "").isNullOrEmpty()) {
            autoConnect { _, _ -> }
        }
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onPause() {
        stopLive()
        super.onPause()
    }

    override fun onDestroy() {
        AdbSession.onStatus = null
        super.onDestroy()
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val uri: Uri? = when (i.action) {
            Intent.ACTION_VIEW -> i.data
            Intent.ACTION_SEND -> i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            else -> null
        }
        if (uri != null) {
            setIntent(Intent())
            installToWatch(uri)
        }
    }

    // ---------------------------------------------------------------- interfaz

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun chip(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.textSize = 13f
        b.stateListAnimator = null
        b.minHeight = 0
        b.minimumHeight = dp(44)
        b.setPadding(dp(6), 0, dp(6), 0)
        val d = GradientDrawable()
        d.cornerRadius = dp(14).toFloat()
        d.setColor(0xFF1E2233.toInt())
        b.background = d
        b.setOnClickListener { onClick() }
        return b
    }

    private fun row(vararg views: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (v in views) {
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            r.addView(v, lp)
        }
        return r
    }

    private fun buildUi() {
        val dm = resources.displayMetrics
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        scroll.isFillViewport = true
        scroll.setOnApplyWindowInsetsListener { v, ins ->
            val b = ins.getInsets(WindowInsets.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            ins
        }

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(12), dp(8), dp(12), dp(24))
        scroll.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val title = TextView(this)
        title.text = "Reloj Remoto · tu Galaxy Watch real"
        title.setTextColor(Color.WHITE)
        title.textSize = 17f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setPadding(0, dp(6), 0, dp(8))
        col.addView(title)

        val size = min(dm.widthPixels - dp(24), (dm.heightPixels * 0.5f).toInt())
        val frame = WatchFrame(this)
        col.addView(frame, LinearLayout.LayoutParams(size, size))

        val d = (size * 0.792f).toInt()
        val box = FrameLayout(this)
        box.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        box.clipToOutline = true
        box.setBackgroundColor(Color.BLACK)
        frame.addView(box, FrameLayout.LayoutParams(d, d, Gravity.CENTER))

        screenImg = ImageView(this)
        screenImg.scaleType = ImageView.ScaleType.FIT_XY
        screenImg.setOnTouchListener { v, e ->
            val b = bmp
            if (b != null) {
                val kx = b.width / v.width.toFloat()
                val ky = b.height / v.height.toFloat()
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.x * kx
                        downY = e.y * ky
                        downT = e.eventTime
                    }
                    MotionEvent.ACTION_UP -> inject(downX, downY, e.x * kx, e.y * ky, e.eventTime - downT, b.width, b.height)
                }
            }
            true
        }
        box.addView(screenImg, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        overlay = TextView(this)
        overlay.text = "Sin conexión.\nToca «Conectar»."
        overlay.setTextColor(0xFF9A9FB5.toInt())
        overlay.gravity = Gravity.CENTER
        overlay.textSize = 13f
        box.addView(overlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        frame.onHome = { key(3) }
        frame.onBack = { key(4) }

        liveBtn = chip("Pantalla en vivo") { toggleLive() }
        val controls = LinearLayout(this)
        controls.orientation = LinearLayout.VERTICAL
        controls.addView(row(chip("Conectar") { showConnect() }, chip("Instalar APK") { pickApk() }, chip("Apps") { showApps() }))
        controls.addView(row(liveBtn, chip("Captura") { screenshot() }, chip("Info") { showInfo() }))
        controls.addView(row(chip("Registro reloj") { showWatchLog() }, chip("Despertar") { key(224) }, chip("Registro app") { showLog() }))
        col.addView(controls, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        statusTv = TextView(this)
        statusTv.setTextColor(0xFFB8BCD0.toInt())
        statusTv.textSize = 13f
        statusTv.setPadding(dp(4), dp(10), dp(4), 0)
        col.addView(statusTv)

        val info = TextView(this)
        info.setTextColor(0xFF7C8098.toInt())
        info.textSize = 12f
        info.setPadding(dp(4), dp(6), dp(4), 0)
        info.text = "Esto es la pantalla REAL de tu reloj, tomada por Wi-Fi (unos pocos fotogramas por segundo). " +
            "Los botones laterales del dibujo envían Inicio y Atrás al reloj."
        col.addView(info)

        setContentView(scroll)
    }

    private fun updateStatus() {
        statusTv.text = if (AdbSession.connected) "Reloj conectado (${AdbSession.peer})" else "Reloj sin conexión"
        if (!AdbSession.connected) {
            stopLive()
            overlay.visibility = View.VISIBLE
            overlay.text = "Sin conexión.\nToca «Conectar»."
        } else if (bmp == null) {
            overlay.visibility = View.VISIBLE
            overlay.text = "Conectado ✓\nToca «Pantalla en vivo»."
        }
    }

    // ---------------------------------------------------------------- conexión

    private fun connectTo(h: String, p: Int, cb: (Boolean, String) -> Unit) {
        AdbSession.connect(h, p) { ok, msg ->
            if (ok) prefs.edit().putString("host", h).putInt("connPort", p).apply()
            cb(ok, if (ok) "Conectado al reloj ✓" else msg)
        }
    }

    private fun autoConnect(cb: (Boolean, String) -> Unit) {
        WatchDiscovery.find(this, WatchDiscovery.TYPE_CONNECT, 5000) { host, port ->
            val h = host ?: (prefs.getString("host", "") ?: "")
            val p = if (host != null) port else prefs.getInt("connPort", 0)
            if (h.isEmpty() || p <= 0) {
                cb(false, "No encuentro el reloj. ¿Depuración inalámbrica activa en el reloj y mismo Wi-Fi?")
            } else {
                connectTo(h, p, cb)
            }
        }
    }

    private fun showConnect() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(8), dp(20), 0)

        val help = TextView(this)
        help.text = "En el RELOJ:\n" +
            "1) Ajustes → Opciones de desarrollador (si no salen: Acerca del reloj → Software y toca 7 veces la versión).\n" +
            "2) Activa «Depuración ADB» y «Depuración inalámbrica». El reloj y el teléfono deben estar en el mismo Wi-Fi.\n" +
            "3) Entra en Depuración inalámbrica → «Vincular nuevo dispositivo»: el reloj muestra IP:puerto y un código.\n\n" +
            "Aquí: pulsa «Buscar reloj (vinculación)», escribe el código y pulsa Vincular. " +
            "Después pulsa «Buscar reloj (conexión)» y Conectar. Si la búsqueda no encuentra nada, escribe IP y puertos a mano."
        help.textSize = 12f
        col.addView(help)

        fun field(hint: String, v: String, number: Boolean): EditText {
            val e = EditText(this)
            e.hint = hint
            if (number) e.inputType = InputType.TYPE_CLASS_NUMBER
            e.setText(v)
            return e
        }

        val ip = field("IP del reloj", prefs.getString("host", "") ?: "", false)
        val pairPort = field("Puerto de vinculación", "", true)
        val code = field("Código de vinculación (6 dígitos)", "", true)
        val connPort = field("Puerto de conexión", if (prefs.getInt("connPort", 0) > 0) prefs.getInt("connPort", 0).toString() else "", true)
        val result = TextView(this)
        result.textSize = 13f
        result.setPadding(0, dp(8), 0, dp(4))

        fun btn(label: String, onClick: () -> Unit): Button {
            val b = Button(this)
            b.text = label
            b.setOnClickListener { onClick() }
            return b
        }

        col.addView(ip)
        col.addView(btn("Buscar reloj (vinculación)") {
            result.text = "Buscando la ventana de vinculación del reloj..."
            WatchDiscovery.find(this, WatchDiscovery.TYPE_PAIRING, 6000) { h, p ->
                runOnUiThread {
                    if (h == null) {
                        result.text = "No lo encuentro. En el reloj abre «Vincular nuevo dispositivo» y vuelve a probar."
                    } else {
                        ip.setText(h)
                        pairPort.setText(p.toString())
                        result.text = "Encontrado: $h:$p. Escribe el código y pulsa Vincular."
                    }
                }
            }
        })
        col.addView(pairPort)
        col.addView(code)
        col.addView(btn("Vincular") {
            val h = ip.text.toString().trim()
            val p = pairPort.text.toString().trim().toIntOrNull()
            val cd = code.text.toString().trim()
            if (h.isEmpty() || p == null || cd.isEmpty()) {
                result.text = "Faltan IP, puerto o código"
            } else {
                result.text = "Vinculando..."
                AdbSession.pair(h, p, cd) { _, msg -> runOnUiThread { result.text = msg } }
            }
        })
        col.addView(btn("Buscar reloj (conexión)") {
            result.text = "Buscando el reloj..."
            WatchDiscovery.find(this, WatchDiscovery.TYPE_CONNECT, 6000) { h, p ->
                runOnUiThread {
                    if (h == null) {
                        result.text = "No lo encuentro. ¿Depuración inalámbrica activa en el reloj?"
                    } else {
                        ip.setText(h)
                        connPort.setText(p.toString())
                        result.text = "Encontrado: $h:$p. Pulsa Conectar."
                    }
                }
            }
        })
        col.addView(connPort)
        col.addView(btn("Conectar") {
            val h = ip.text.toString().trim()
            val p = connPort.text.toString().trim().toIntOrNull()
            if (h.isEmpty() || p == null) {
                result.text = "Faltan IP o puerto de conexión"
            } else {
                result.text = "Conectando..."
                connectTo(h, p) { _, msg -> runOnUiThread { result.text = msg } }
            }
        })
        col.addView(result)

        val sv = ScrollView(this)
        sv.addView(col)
        AlertDialog.Builder(this)
            .setTitle("Conectar con el reloj")
            .setView(sv)
            .setNeutralButton("Desconectar") { _, _ -> AdbSession.disconnect() }
            .setPositiveButton("Cerrar", null)
            .show()
    }

    // ---------------------------------------------------------------- control del reloj

    private fun needConnection(): Boolean {
        if (AdbSession.connected) return true
        toast("Primero conecta el reloj")
        showConnect()
        return false
    }

    private fun key(code: Int) {
        if (!AdbSession.connected) {
            toast("Reloj sin conexión")
            return
        }
        AdbSession.shell("input keyevent $code")
    }

    private fun inject(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long, w: Int, h: Int) {
        if (!AdbSession.connected) return
        fun cx(v: Float): Int = v.toInt().coerceIn(0, w - 1)
        fun cy(v: Float): Int = v.toInt().coerceIn(0, h - 1)
        val dist = hypot(x2 - x1, y2 - y1)
        val cmd = if (dist < 14f) {
            if (dur >= 450L) {
                "input swipe ${cx(x1)} ${cy(y1)} ${cx(x1)} ${cy(y1)} ${dur.coerceAtMost(3000L)}"
            } else {
                "input tap ${cx(x1)} ${cy(y1)}"
            }
        } else {
            "input swipe ${cx(x1)} ${cy(y1)} ${cx(x2)} ${cy(y2)} ${dur.coerceIn(80L, 1500L)}"
        }
        AdbSession.shell(cmd)
    }

    // ---------------------------------------------------------------- pantalla en vivo

    private fun toggleLive() {
        if (live) stopLive() else startLive()
    }

    private fun startLive() {
        if (!needConnection()) return
        live = true
        failures = 0
        liveBtn.text = "Pausar"
        AdbSession.shell("input keyevent 224")
        scheduleFrame()
    }

    private fun stopLive() {
        live = false
        if (::liveBtn.isInitialized) liveBtn.text = "Pantalla en vivo"
    }

    private fun scheduleFrame() {
        if (!live) return
        AdbSession.exec {
            val out = AdbSession.shellRaw("screencap -p | base64")
            val b: Bitmap? = try {
                val bytes = Base64.decode(out, Base64.DEFAULT)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            } catch (_: Throwable) {
                null
            }
            runOnUiThread {
                if (b != null) {
                    failures = 0
                    bmp = b
                    screenImg.setImageBitmap(b)
                    overlay.visibility = View.GONE
                } else {
                    failures++
                    AdbSession.log("Fotograma inválido: " + out.take(120))
                    if (failures >= 3) {
                        stopLive()
                        toast("No pude leer la pantalla del reloj. Mira «Registro app».")
                    }
                }
                if (live) main.postDelayed({ scheduleFrame() }, 120)
            }
        }
    }

    private fun screenshot() {
        val b = bmp
        if (b == null) {
            toast("Primero activa «Pantalla en vivo»")
            return
        }
        try {
            val out = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            val path = Path()
            path.addCircle(b.width / 2f, b.height / 2f, b.width / 2f, Path.Direction.CW)
            c.clipPath(path)
            c.drawBitmap(b, 0f, 0f, null)
            val values = ContentValues()
            val name = "Reloj-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".png"
            values.put(MediaStore.Images.Media.DISPLAY_NAME, name)
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/RelojRemoto")
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri == null) {
                toast("No se pudo guardar la captura")
                return
            }
            contentResolver.openOutputStream(uri)?.use { os -> out.compress(Bitmap.CompressFormat.PNG, 100, os) }
            toast("Captura guardada en Imágenes/RelojRemoto")
        } catch (t: Throwable) {
            toast("Captura falló: ${t.message}")
        }
    }

    // ---------------------------------------------------------------- instalar APK

    private fun pickApk() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(
            Intent.EXTRA_MIME_TYPES,
            arrayOf("application/vnd.android.package-archive", "application/octet-stream")
        )
        startActivityForResult(i, reqPickApk)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqPickApk && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            installToWatch(uri)
        }
    }

    /** Envía el APK al reloj por ADB (en trozos) y lo instala con pm install. */
    private fun installToWatch(uri: Uri) {
        if (!needConnection()) return
        val tv = TextView(this)
        tv.setPadding(dp(20), dp(16), dp(20), dp(16))
        tv.text = "Preparando..."
        AlertDialog.Builder(this)
            .setTitle("Instalando en el reloj")
            .setView(tv)
            .setPositiveButton("Cerrar", null)
            .show()

        fun say(s: String) {
            runOnUiThread { tv.text = s }
        }

        AdbSession.exec {
            try {
                val data = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: throw IllegalStateException("no se pudo leer el APK")
                val remote = "/data/local/tmp/relojremoto.apk"
                AdbSession.shellRaw("rm -f $remote")
                val chunk = 30000
                var off = 0
                while (off < data.size) {
                    val end = min(off + chunk, data.size)
                    val b64 = Base64.encodeToString(data.copyOfRange(off, end), Base64.NO_WRAP)
                    val r = AdbSession.shellRaw("echo $b64 | base64 -d >> $remote")
                    if (r.contains("not found", true) || r.contains("error", true) || r.startsWith("ERROR")) {
                        throw IllegalStateException(r)
                    }
                    off = end
                    say("Enviando al reloj... ${off * 100L / data.size} %")
                }
                say("Instalando...")
                val out = AdbSession.shellNow("pm install -r -t $remote")
                AdbSession.shellRaw("rm -f $remote")
                say(if (out.contains("Success")) "Instalado ✓\nYa puedes abrirla desde «Apps»." else "Resultado:\n$out")
            } catch (t: Throwable) {
                AdbSession.log("Instalar falló: $t")
                say("Error: ${t.message}")
            }
        }
    }

    // ---------------------------------------------------------------- apps, info, registros

    private fun showApps() {
        if (!needConnection()) return
        AdbSession.shell("pm list packages -3") { out ->
            val pk = out.split("\n")
                .map { it.trim().removePrefix("package:") }
                .filter { it.isNotEmpty() && !it.contains(" ") }
                .sorted()
            runOnUiThread {
                if (pk.isEmpty()) {
                    toast("No hay apps instaladas por ti en el reloj")
                } else {
                    AlertDialog.Builder(this)
                        .setTitle("Apps instaladas en el reloj")
                        .setItems(pk.toTypedArray()) { _, i -> appActions(pk[i]) }
                        .setNegativeButton("Cerrar", null)
                        .show()
                }
            }
        }
    }

    private fun appActions(pkg: String) {
        val items = arrayOf("Abrir", "Detener", "Borrar datos", "Desinstalar")
        AlertDialog.Builder(this)
            .setTitle(pkg)
            .setItems(items) { _, w ->
                when (w) {
                    0 -> AdbSession.shell("monkey -p $pkg -c android.intent.category.LAUNCHER 1")
                    1 -> AdbSession.shell("am force-stop $pkg")
                    2 -> AdbSession.shell("pm clear $pkg") { toast(it) }
                    3 -> AdbSession.shell("pm uninstall $pkg") { toast(it) }
                    else -> {}
                }
            }
            .show()
    }

    private fun showText(title: String, text: String, refresh: (() -> Unit)?) {
        val tv = TextView(this)
        tv.text = text
        tv.typeface = Typeface.MONOSPACE
        tv.textSize = 11f
        tv.setTextIsSelectable(true)
        tv.setPadding(dp(16), dp(8), dp(16), dp(8))
        val sv = ScrollView(this)
        sv.addView(tv)
        val b = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(sv)
            .setNeutralButton("Copiar") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText(title, text))
                toast("Copiado")
            }
            .setPositiveButton("Cerrar", null)
        if (refresh != null) b.setNegativeButton("Actualizar") { _, _ -> refresh() }
        b.show()
    }

    private fun showInfo() {
        if (!needConnection()) return
        val cmd = "(echo \"Modelo: \$(getprop ro.product.model)\"; " +
            "echo \"Android: \$(getprop ro.build.version.release) (API \$(getprop ro.build.version.sdk))\"; " +
            "echo \"Pantalla: \$(wm size | tail -n 1)\"; " +
            "echo \"Densidad: \$(wm density | tail -n 1)\"; " +
            "echo \"Escala de fuente: \$(settings get system font_scale)\"; " +
            "echo \"Paquetes WebView: \$(pm list packages | grep -c webview)\")"
        AdbSession.shell(cmd) { out -> runOnUiThread { showText("Tu reloj", out, null) } }
    }

    private fun showWatchLog() {
        if (!needConnection()) return
        AdbSession.shell("logcat -d -t 400 '*:W'") { out ->
            runOnUiThread { showText("Registro del reloj (avisos y errores)", out) { showWatchLog() } }
        }
    }

    private fun showLog() {
        showText("Registro de la app", AdbSession.logText(), null)
    }

    private fun toast(s: String) {
        runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }
    }
}

package com.watchlink.app

import android.content.Context
import com.flyfishxu.kadb.Kadb
import kotlinx.coroutines.runBlocking
import java.util.concurrent.Executors

/** Conexión ADB por Wi-Fi con el reloj (Depuración inalámbrica del reloj). */
object AdbSession {
    private val executor = Executors.newSingleThreadExecutor()
    private var kadb: Kadb? = null
    private val lines = ArrayList<String>()

    @Volatile
    var connected = false
        private set

    @Volatile
    var peer = ""
        private set

    var onStatus: (() -> Unit)? = null

    @Volatile
    private var lastHost = ""

    @Volatile
    private var lastPort = 0

    fun init(ctx: Context) {
        // Donde la librería guarda la identidad (clave) ADB para no volver a vincular.
        try {
            System.setProperty("user.home", ctx.filesDir.absolutePath)
        } catch (_: Throwable) {
        }
    }

    @Synchronized
    fun log(s: String) {
        val t = if (s.length > 600) s.substring(0, 600) + "…" else s
        for (l in t.split("\n")) {
            lines.add(l)
        }
        while (lines.size > 300) lines.removeAt(0)
    }

    @Synchronized
    fun logText(): String = if (lines.isEmpty()) "(vacío)" else lines.joinToString("\n")

    private fun <T> blocking(block: suspend () -> T): T = runBlocking { block() }

    private fun post(task: () -> Unit) {
        executor.execute {
            try {
                task()
            } catch (t: Throwable) {
                log("ERROR: $t")
            }
        }
    }

    /** Ejecuta una tarea en la cola ADB (todas las órdenes van una tras otra). */
    fun exec(task: () -> Unit) = post(task)

    private fun closeQuiet() {
        try {
            (kadb as? AutoCloseable)?.close()
        } catch (_: Throwable) {
        }
        kadb = null
    }

    private fun setConnected(v: Boolean, who: String = "") {
        connected = v
        peer = if (v) who else ""
        onStatus?.invoke()
    }

    fun pair(host: String, port: Int, code: String, done: (Boolean, String) -> Unit) = post {
        try {
            log("Vinculando con $host:$port ...")
            val r: Any? = blocking { Kadb.pair(host, port, code) }
            if (r == false) {
                log("Vinculación rechazada")
                done(false, "Código o puerto incorrecto")
            } else {
                log("Vinculación correcta")
                done(true, "Vinculado. Ahora pulsa Conectar.")
            }
        } catch (t: Throwable) {
            log("Vincular falló: $t")
            done(false, t.message ?: t.toString())
        }
    }

    fun connect(host: String, port: Int, done: (Boolean, String) -> Unit) = post {
        try {
            log("Conectando a $host:$port ...")
            closeQuiet()
            val k = blocking { Kadb.create(host, port) }
            val r = blocking { k.shell("echo ok") }
            if (r.exitCode != 0) throw IllegalStateException("echo devolvió ${r.exitCode}")
            kadb = k
            lastHost = host
            lastPort = port
            setConnected(true, "$host:$port")
            log("Conectado al reloj")
            done(true, "Conectado")
        } catch (t: Throwable) {
            setConnected(false)
            log("Conectar falló: $t")
            done(false, t.message ?: t.toString())
        }
    }

    fun disconnect() = post {
        closeQuiet()
        setConnected(false)
        log("Desconectado")
    }

    /** Orden de shell en segundo plano; [done] recibe stdout+stderr. */
    fun shell(cmd: String, done: ((String) -> Unit)? = null) = post {
        done?.invoke(shellNow(cmd))
    }

    /** Solo dentro de [exec]/[shell]: ejecuta y devuelve stdout+stderr. */
    fun shellNow(cmd: String): String = shellSync("$cmd 2>&1", false)

    /** Solo dentro de [exec]: ejecuta tal cual y sin registrar (para datos binarios o grandes). */
    fun shellRaw(cmd: String): String = shellSync(cmd, true)

    private fun runOn(k: Kadb, cmd: String, quiet: Boolean): String {
        val r = blocking { k.shell(cmd) }
        val out = r.output.trim()
        if (!quiet && out.isNotEmpty()) log(out)
        return out
    }

    private fun shellSync(cmd: String, quiet: Boolean): String {
        val k = kadb ?: return "ADB no conectado"
        if (!quiet) log("$ $cmd")
        return try {
            runOn(k, cmd, quiet)
        } catch (t: Throwable) {
            log("Reintentando tras: $t")
            try {
                closeQuiet()
                if (lastPort <= 0) throw IllegalStateException("sin puerto")
                val k2 = blocking { Kadb.create(lastHost, lastPort) }
                kadb = k2
                runOn(k2, cmd, quiet)
            } catch (t2: Throwable) {
                setConnected(false)
                log("Conexión perdida: $t2")
                "ERROR: conexión perdida (${t2.message})"
            }
        }
    }
}

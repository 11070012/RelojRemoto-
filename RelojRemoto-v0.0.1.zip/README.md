# Reloj Remoto v0.0.1
Controla tu Galaxy Watch REAL desde el teléfono por Wi-Fi (ADB inalámbrico): pantalla real, instalar APK sin Bugjaeger, apps, info y registros.
Subir el .zip tal cual a un repositorio nuevo de GitHub; el workflow compila y publica RelojRemoto-v0.0.1-debug.apk en Releases.

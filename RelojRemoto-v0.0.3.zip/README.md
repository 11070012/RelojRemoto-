# Reloj Remoto v0.0.3
Controla tu Galaxy Watch REAL desde el teléfono por Wi-Fi (ADB inalámbrico): pantalla real, instalar APK sin Bugjaeger, apps, info y registros.
Subir el .zip tal cual a un repositorio nuevo de GitHub; el workflow compila y publica RelojRemoto-v0.0.2-debug.apk en Releases.

v0.0.2: la instalación envía el APK por trozos (sin límite de tamaño) y prueba varios métodos ADB: principal + 6 respaldos y, si nada funciona, desinstalar y reinstalar (con confirmación).

v0.0.3: la pantalla redonda es un touchpad (toque, mantener, deslizar y arrastrar), modo pantalla completa y FPS elegible.

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val appVersionName = "0.0.3"
val appVersionCode = 3

// APK con la versión en el nombre: RelojRemoto-v0.0.1-debug.apk
base {
    archivesName.set("RelojRemoto-v$appVersionName")
}

android {
    namespace = "com.watchlink.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.watchlink.app"
        minSdk = 30
        targetSdk = 35
        versionCode = appVersionCode
        versionName = appVersionName
    }

    // Keystore fija: así cada versión nueva se instala encima de la anterior sin desinstalar.
    signingConfigs {
        getByName("debug") {
            storeFile = file("relojremoto.keystore")
            storePassword = "android"
            keyAlias = "relojremoto"
            keyPassword = "android"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("debug")
        }
        getByName("release") {
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "META-INF/INDEX.LIST",
                "META-INF/DEPENDENCIES",
                "META-INF/versions/**",
                "META-INF/**/OSGI-INF/MANIFEST.MF",
                "META-INF/LICENSE*",
                "META-INF/NOTICE*",
                "META-INF/*.md",
                "META-INF/*.txt"
            )
            pickFirsts += setOf("META-INF/MANIFEST.MF", "**/module-info.class")
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
        freeCompilerArgs.add("-Xskip-metadata-version-check")
    }
}

dependencies {
    implementation("com.flyfishxu:kadb:2.1.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}

// kadb-android declara que exige compileSdk 37 (solo metadato); AGP 8.9 llega a 36.
// La librería funciona igual compilando contra 35, así que se desactiva solo esa comprobación.
tasks.configureEach {
    if (name.startsWith("check") && name.endsWith("AarMetadata")) {
        enabled = false
    }
}

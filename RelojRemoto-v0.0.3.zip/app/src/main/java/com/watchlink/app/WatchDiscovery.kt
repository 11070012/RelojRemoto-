package com.watchlink.app

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Handler
import android.os.Looper
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface

/** Busca el reloj en la red Wi-Fi (mDNS) para no tener que escribir IP ni puertos. */
object WatchDiscovery {
    const val TYPE_CONNECT = "_adb-tls-connect._tcp"
    const val TYPE_PAIRING = "_adb-tls-pairing._tcp"

    private fun isLocal(h: InetAddress): Boolean {
        if (h.isLoopbackAddress) return true
        return try {
            NetworkInterface.getNetworkInterfaces().toList().any { ni -> ni.inetAddresses.toList().any { it == h } }
        } catch (_: Throwable) {
            false
        }
    }

    /** Devuelve (ip, puerto) del primer servicio ADB que NO sea este teléfono, o (null, 0) si no aparece. */
    fun find(ctx: Context, type: String, timeoutMs: Long, cb: (String?, Int) -> Unit) {
        val nsd = ctx.applicationContext.getSystemService(Context.NSD_SERVICE) as NsdManager
        val main = Handler(Looper.getMainLooper())
        var done = false
        lateinit var listener: NsdManager.DiscoveryListener

        fun finish(host: String?, port: Int) {
            if (done) return
            done = true
            main.removeCallbacksAndMessages(null)
            try {
                nsd.stopServiceDiscovery(listener)
            } catch (_: Throwable) {
            }
            cb(host, port)
        }

        listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) {}
            override fun onServiceFound(info: NsdServiceInfo) {
                try {
                    @Suppress("DEPRECATION")
                    nsd.resolveService(info, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(i: NsdServiceInfo, code: Int) {}
                        override fun onServiceResolved(i: NsdServiceInfo) {
                            val h = i.host
                            if (h is Inet4Address && !isLocal(h)) finish(h.hostAddress, i.port)
                        }
                    })
                } catch (t: Throwable) {
                    AdbSession.log("resolveService: $t")
                }
            }

            override fun onServiceLost(info: NsdServiceInfo) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onStartDiscoveryFailed(t: String, code: Int) {
                finish(null, 0)
            }

            override fun onStopDiscoveryFailed(t: String, code: Int) {}
        }
        try {
            nsd.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, listener)
            main.postDelayed({ finish(null, 0) }, timeoutMs)
        } catch (t: Throwable) {
            AdbSession.log("discoverServices: $t")
            cb(null, 0)
        }
    }
}

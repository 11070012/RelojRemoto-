package com.watchlink.app

import android.content.Context
import android.net.Uri
import android.util.Base64
import java.io.File
import java.io.FileInputStream

/**
 * Instalación del APK en el reloj con varios métodos de ADB.
 * El método 1 es el principal (el de siempre); los demás son respaldo y se prueban en orden.
 * Nada se carga entero en memoria: todo va por trozos.
 */
object Installer {
    private const val REMOTE = "/data/local/tmp/relojremoto.apk"

    private fun ok(s: String) = s.contains("Success") && !s.contains("Failure", true)

    private fun short(s: String): String {
        val t = s.trim().replace("\n", " ")
        return if (t.length > 160) t.substring(0, 160) + "…" else t
    }

    private fun copyToCache(ctx: Context, uri: Uri, progress: (Int) -> Unit): File {
        val out = File(ctx.cacheDir, "instalar.apk")
        val total = try {
            ctx.contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L
        } catch (_: Throwable) {
            -1L
        }
        val ins = ctx.contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("no se pudo leer el APK")
        ins.use { i ->
            out.outputStream().use { o ->
                val buf = ByteArray(256 * 1024)
                var done = 0L
                var last = -1
                while (true) {
                    val n = i.read(buf)
                    if (n < 0) break
                    o.write(buf, 0, n)
                    done += n
                    if (total > 0) {
                        val p = (done * 100 / total).toInt()
                        if (p != last) {
                            last = p
                            progress(p)
                        }
                    }
                }
            }
        }
        return out
    }

    /** Método 1 (principal): envía por shell en base64 y usa pm install. */
    private fun principal(f: File, progress: (Int) -> Unit): String {
        AdbSession.shellRaw("rm -f $REMOTE")
        val chunk = 30000
        val buf = ByteArray(chunk)
        val total = f.length()
        var sent = 0L
        FileInputStream(f).use { ins ->
            while (true) {
                var n = 0
                while (n < chunk) {
                    val r = ins.read(buf, n, chunk - n)
                    if (r < 0) break
                    n += r
                }
                if (n == 0) break
                val b64 = Base64.encodeToString(buf, 0, n, Base64.NO_WRAP)
                val r = AdbSession.shellRaw("echo $b64 | base64 -d >> $REMOTE")
                if (r.contains("not found", true) || r.contains("error", true) || r.startsWith("ERROR")) {
                    throw IllegalStateException(r)
                }
                sent += n
                progress((sent * 100 / total).toInt())
                if (n < chunk) break
            }
        }
        return AdbSession.shellNow("pm install -r -t $REMOTE")
    }

    /** Asegura que el APK esté completo en el reloj (lo copia con push si hace falta). */
    private fun ensureStaged(f: File): String? {
        val size = f.length()
        val have = AdbSession.shellRaw("stat -c %s $REMOTE 2>/dev/null").trim()
        if (have == size.toString()) return null
        AdbSession.shellRaw("rm -f $REMOTE")
        val r = AdbSession.pushFile(f, REMOTE)
        if (r != "OK") return r
        val after = AdbSession.shellRaw("stat -c %s $REMOTE 2>/dev/null").trim()
        // Si "stat" no existe en el reloj, se da por bueno lo que devolvió push.
        if (after.isNotEmpty() && after.all { it.isDigit() } && after != size.toString()) {
            return "ERROR: tamaño distinto en el reloj ($after de $size)"
        }
        return null
    }

    private fun staged(f: File, cmd: String): String {
        ensureStaged(f)?.let { return it }
        return AdbSession.shellNow("$cmd $REMOTE")
    }

    private fun session(f: File): String {
        ensureStaged(f)?.let { return it }
        val size = f.length()
        val created = AdbSession.shellNow("pm install-create -r -t -d -g -S $size")
        val id = Regex("\\[(\\d+)\\]").find(created)?.groupValues?.get(1)
            ?: return "No se pudo crear la sesión: $created"
        val w = AdbSession.shellNow("pm install-write -S $size $id base.apk $REMOTE")
        if (!ok(w)) {
            AdbSession.shellNow("pm install-abandon $id")
            return "install-write: $w"
        }
        return AdbSession.shellNow("pm install-commit $id")
    }

    /**
     * Instala [uri] en el reloj. [say] recibe el texto de progreso; [ask] pregunta algo al usuario
     * (se usa antes de desinstalar la versión anterior, que borra los datos de la app).
     */
    fun install(
        ctx: Context,
        uri: Uri,
        say: (String) -> Unit,
        ask: (String, (Boolean) -> Unit) -> Unit
    ) {
        AdbSession.exec {
            val log = StringBuilder()
            fun step(s: String) {
                log.append(s).append('\n')
                say(log.toString())
            }
            fun live(s: String) = say(log.toString() + s)

            var file: File? = null
            try {
                step("Preparando el APK…")
                val f = copyToCache(ctx, uri) { live("Copiando… $it %") }
                file = f
                val pkg = ctx.packageManager.getPackageArchiveInfo(f.absolutePath, 0)?.packageName
                step("APK de ${f.length() / 1024 / 1024} MB" + (if (pkg != null) " ($pkg)" else ""))

                val methods: List<Pair<String, () -> String>> = listOf(
                    "Principal: base64 por shell + pm install" to { principal(f) { p -> live("Enviando… $p %") } },
                    "Directa: install de la librería" to { AdbSession.installDirect(f, "-r", "-t", "-d", "-g") },
                    "Copiar + pm install -r -t -d -g" to { staged(f, "pm install -r -t -d -g") },
                    "Copiar + cmd package install" to { staged(f, "cmd package install -r -t -d -g") },
                    "Por sesión: create / write / commit" to { session(f) },
                    "Copiar + pm install -r (sin otras opciones)" to { staged(f, "pm install -r") },
                    "Copiar + pm install (mínimo)" to { staged(f, "pm install") }
                )

                var needUninstall = false
                for ((i, m) in methods.withIndex()) {
                    val (name, run) = m
                    step("Método ${i + 1}/${methods.size}: $name")
                    val out = try {
                        run()
                    } catch (t: Throwable) {
                        "ERROR: ${t.message ?: t}"
                    }
                    if (ok(out)) {
                        AdbSession.shellRaw("rm -f $REMOTE")
                        step("")
                        step(if (i == 0) "Instalado ✓ (método principal)" else "Instalado ✓ (respaldo ${i}: ${name})")
                        step("Ya puedes abrirla desde «Apps».")
                        return@exec
                    }
                    step("   ✖ ${short(out)}")
                    if (out.contains("NO_MATCHING_ABIS") || out.contains("INSUFFICIENT_STORAGE")) {
                        AdbSession.shellRaw("rm -f $REMOTE")
                        step("")
                        step(
                            if (out.contains("ABIS")) "Este APK no trae librerías para la arquitectura del reloj; ningún método de instalación lo arregla."
                            else "No hay espacio suficiente en el reloj; libera almacenamiento y vuelve a intentar."
                        )
                        return@exec
                    }
                    if (out.contains("UPDATE_INCOMPATIBLE") || out.contains("signatures do not match", true)) {
                        needUninstall = true
                        break
                    }
                }

                step("")
                if (pkg == null) {
                    AdbSession.shellRaw("rm -f $REMOTE")
                    step("Ningún método funcionó.")
                    return@exec
                }
                step(
                    if (needUninstall) "La versión instalada tiene otra firma."
                    else "Ningún método funcionó."
                )
                ask("¿Desinstalar $pkg del reloj y reinstalar?\n\nEsto borra los datos de esa app.") { yes ->
                    if (!yes) {
                        AdbSession.exec {
                            AdbSession.shellRaw("rm -f $REMOTE")
                            step("Cancelado.")
                        }
                        return@ask
                    }
                    AdbSession.exec {
                        try {
                            step("Último recurso: desinstalar y reinstalar")
                            val u = AdbSession.shellNow("pm uninstall $pkg")
                            step("   desinstalar: ${short(u)}")
                            val out = staged(file!!, "pm install -t")
                            AdbSession.shellRaw("rm -f $REMOTE")
                            step(if (ok(out)) "Instalado ✓ (tras desinstalar la anterior)" else "   ✖ ${short(out)}")
                        } catch (t: Throwable) {
                            step("Error: ${t.message}")
                        }
                    }
                }
            } catch (t: Throwable) {
                AdbSession.log("Instalar falló: $t")
                step("Error: ${t.message}")
            }
        }
    }
}

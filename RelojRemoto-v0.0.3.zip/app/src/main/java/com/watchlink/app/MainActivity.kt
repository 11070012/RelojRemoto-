package com.watchlink.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.hypot
import kotlin.math.min

class MainActivity : Activity() {

    private val bg = 0xFF0B0D14.toInt()
    private val reqPickApk = 21
    private val main = Handler(Looper.getMainLooper())

    private lateinit var prefs: SharedPreferences
    private lateinit var screenImg: ImageView
    private lateinit var overlay: TextView
    private lateinit var statusTv: TextView
    private lateinit var liveBtn: Button

    private var live = false
    private var failures = 0
    private var bmp: Bitmap? = null

    private val pad = TouchPad()
    private var fps = 10
    private var fullscreen = false
    private var lastFrameT = 0L
    private var fpsAvg = 0f
    private lateinit var fpsTv: TextView
    private lateinit var fpsBtn: Button
    private lateinit var padBtn: Button
    private lateinit var fsFpsBtn: Button
    private lateinit var fsPadBtn: Button
    private lateinit var fsLayer: FrameLayout
    private lateinit var fsBox: FrameLayout
    private lateinit var fsImg: ImageView
    private lateinit var fsInfo: TextView

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("relojremoto", Context.MODE_PRIVATE)
        fps = prefs.getInt("fps", 10).coerceIn(1, 30)
        pad.mode = prefs.getInt("padMode", TouchPad.GESTOS).coerceIn(0, 2)
        pad.onNote = { s -> runOnUiThread { toast(s) } }
        AdbSession.init(this)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        AdbSession.onStatus = { runOnUiThread { updateStatus() } }
        updateStatus()

        // Reconexión automática si ya habías conectado alguna vez.
        if (!prefs.getString("host", "").isNullOrEmpty()) {
            autoConnect { _, _ -> }
        }
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onPause() {
        stopLive()
        super.onPause()
    }

    override fun onDestroy() {
        AdbSession.onStatus = null
        super.onDestroy()
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val uri: Uri? = when (i.action) {
            Intent.ACTION_VIEW -> i.data
            Intent.ACTION_SEND -> i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            else -> null
        }
        if (uri != null) {
            setIntent(Intent())
            installToWatch(uri)
        }
    }

    // ---------------------------------------------------------------- interfaz

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun chip(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.textSize = 13f
        b.stateListAnimator = null
        b.minHeight = 0
        b.minimumHeight = dp(44)
        b.setPadding(dp(6), 0, dp(6), 0)
        val d = GradientDrawable()
        d.cornerRadius = dp(14).toFloat()
        d.setColor(0xFF1E2233.toInt())
        b.background = d
        b.setOnClickListener { onClick() }
        return b
    }

    private fun row(vararg views: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (v in views) {
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            r.addView(v, lp)
        }
        return r
    }

    private fun buildUi() {
        val dm = resources.displayMetrics
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        scroll.isFillViewport = true
        scroll.setOnApplyWindowInsetsListener { v, ins ->
            val b = ins.getInsets(WindowInsets.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            ins
        }

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(12), dp(8), dp(12), dp(24))
        scroll.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val title = TextView(this)
        title.text = "Reloj Remoto · tu Galaxy Watch real"
        title.setTextColor(Color.WHITE)
        title.textSize = 17f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setPadding(0, dp(6), 0, dp(8))
        col.addView(title)

        val size = min(dm.widthPixels - dp(24), (dm.heightPixels * 0.5f).toInt())
        val frame = WatchFrame(this)
        col.addView(frame, LinearLayout.LayoutParams(size, size))

        val d = (size * 0.792f).toInt()
        val box = FrameLayout(this)
        box.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        box.clipToOutline = true
        box.setBackgroundColor(Color.BLACK)
        frame.addView(box, FrameLayout.LayoutParams(d, d, Gravity.CENTER))

        screenImg = ImageView(this)
        screenImg.scaleType = ImageView.ScaleType.FIT_XY
        attachPad(screenImg)
        box.addView(screenImg, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        overlay = TextView(this)
        overlay.text = "Sin conexión.\nToca «Conectar»."
        overlay.setTextColor(0xFF9A9FB5.toInt())
        overlay.gravity = Gravity.CENTER
        overlay.textSize = 13f
        box.addView(overlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        frame.onHome = { key(3) }
        frame.onBack = { key(4) }

        liveBtn = chip("Pantalla en vivo") { toggleLive() }
        val controls = LinearLayout(this)
        controls.orientation = LinearLayout.VERTICAL
        controls.addView(row(chip("Conectar") { showConnect() }, chip("Instalar APK") { pickApk() }, chip("Apps") { showApps() }))
        controls.addView(row(liveBtn, chip("Captura") { screenshot() }, chip("Info") { showInfo() }))
        controls.addView(row(chip("Registro reloj") { showWatchLog() }, chip("Despertar") { key(224) }, chip("Registro app") { showLog() }))
        fpsBtn = chip("") { showFps() }
        padBtn = chip("") { showPadMode() }
        controls.addView(row(chip("⤢ Pantalla completa") { enterFullscreen() }, fpsBtn, padBtn))
        col.addView(controls, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        fpsTv = TextView(this)
        fpsTv.setTextColor(0xFF9A9FB5.toInt())
        fpsTv.textSize = 12f
        fpsTv.setPadding(dp(4), dp(6), dp(4), 0)
        col.addView(fpsTv)

        statusTv = TextView(this)
        statusTv.setTextColor(0xFFB8BCD0.toInt())
        statusTv.textSize = 13f
        statusTv.setPadding(dp(4), dp(10), dp(4), 0)
        col.addView(statusTv)

        val info = TextView(this)
        info.setTextColor(0xFF7C8098.toInt())
        info.textSize = 12f
        info.setPadding(dp(4), dp(6), dp(4), 0)
        info.text = "Esto es la pantalla REAL de tu reloj, tomada por Wi-Fi. Toca, mantén o arrastra sobre el círculo " +
            "y el reloj real lo recibe. «FPS» elige cuántos fotogramas por segundo pides; «Control» elige cómo se envían " +
            "los toques; «Pantalla completa» agranda el círculo. Los botones laterales del dibujo envían Inicio y Atrás."
        col.addView(info)

        val root = FrameLayout(this)
        root.setBackgroundColor(bg)
        root.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        fsLayer = buildFsLayer()
        fsLayer.visibility = View.GONE
        root.addView(fsLayer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        refreshLabels()
    }

    // ---------------------------------------------------------------- táctil, FPS y pantalla completa

    /** Todo lo que hagas con el dedo sobre la pantalla redonda se manda al reloj real. */
    private fun attachPad(v: View) {
        v.setOnTouchListener { vw, e ->
            val b = bmp
            if (b != null && vw.width > 0 && vw.height > 0) {
                val x = e.x * b.width / vw.width.toFloat()
                val y = e.y * b.height / vw.height.toFloat()
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        vw.parent?.requestDisallowInterceptTouchEvent(true)
                        pad.down(x, y, e.eventTime, b.width, b.height)
                    }
                    MotionEvent.ACTION_MOVE -> pad.move(x, y, e.eventTime)
                    MotionEvent.ACTION_UP -> pad.up(x, y, e.eventTime)
                    MotionEvent.ACTION_CANCEL -> pad.cancel()
                }
            }
            true
        }
    }

    private fun padName(): String = when (pad.mode) {
        TouchPad.SENDEVENT -> "Control: rápido"
        TouchPad.MOTION -> "Control: compatible"
        else -> "Control: gestos"
    }

    private fun refreshLabels() {
        fpsBtn.text = "FPS: $fps"
        padBtn.text = padName()
        if (::fsFpsBtn.isInitialized) {
            fsFpsBtn.text = "FPS $fps"
            fsPadBtn.text = padName()
        }
        fpsTv.text = "Objetivo: $fps fps"
    }

    private fun showFps() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(12), dp(20), 0)
        val label = TextView(this)
        label.textSize = 18f
        label.text = "$fps fotogramas por segundo"
        val bar = SeekBar(this)
        bar.max = 29
        bar.progress = fps - 1
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                label.text = "${p + 1} fotogramas por segundo"
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        val note = TextView(this)
        note.textSize = 12f
        note.setPadding(0, dp(10), 0, 0)
        note.text = "Es el máximo que pides. Los fotogramas reales dependen de la velocidad del reloj y del Wi-Fi; " +
            "abajo del círculo verás los reales."
        col.addView(label)
        col.addView(bar)
        col.addView(note)
        AlertDialog.Builder(this)
            .setTitle("Fotogramas por segundo")
            .setView(col)
            .setPositiveButton("Aplicar") { _, _ ->
                fps = bar.progress + 1
                prefs.edit().putInt("fps", fps).apply()
                refreshLabels()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showPadMode() {
        val items = arrayOf(
            "Gestos: un solo comando al soltar (el más estable)",
            "Tiempo real rápido: escribe en el táctil del reloj (experimental)",
            "Tiempo real compatible: input motionevent (más lento)"
        )
        AlertDialog.Builder(this)
            .setTitle("Cómo se envían los toques")
            .setSingleChoiceItems(items, pad.mode) { d, which ->
                pad.mode = which
                prefs.edit().putInt("padMode", which).apply()
                refreshLabels()
                d.dismiss()
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun buildFsLayer(): FrameLayout {
        val l = FrameLayout(this)
        l.setBackgroundColor(Color.BLACK)

        fsBox = FrameLayout(this)
        fsBox.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        fsBox.clipToOutline = true
        fsBox.setBackgroundColor(Color.BLACK)
        fsImg = ImageView(this)
        fsImg.scaleType = ImageView.ScaleType.FIT_XY
        attachPad(fsImg)
        fsBox.addView(fsImg, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        l.addView(fsBox, FrameLayout.LayoutParams(dp(100), dp(100), Gravity.CENTER_HORIZONTAL or Gravity.TOP))

        fsInfo = TextView(this)
        fsInfo.setTextColor(0xFF9A9FB5.toInt())
        fsInfo.textSize = 12f
        fsInfo.setPadding(dp(10), dp(10), dp(10), 0)
        l.addView(fsInfo, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))

        fsFpsBtn = chip("") { showFps() }
        fsPadBtn = chip("") { showPadMode() }
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.VERTICAL
        bar.setBackgroundColor(0xCC0B0D14.toInt())
        bar.addView(row(chip("✕ Salir") { exitFullscreen() }, chip("◀ Atrás") { key(4) }, chip("⌂ Inicio") { key(3) }))
        bar.addView(row(fsFpsBtn, fsPadBtn, chip("Despertar") { key(224) }))
        l.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        return l
    }

    private fun enterFullscreen() {
        if (fullscreen) return
        if (!needConnection()) return
        fullscreen = true
        val r = windowManager.currentWindowMetrics.bounds
        val barH = dp(120)
        val d = min(r.width(), r.height() - barH)
        val lp = FrameLayout.LayoutParams(d, d, Gravity.CENTER_HORIZONTAL or Gravity.TOP)
        lp.topMargin = ((r.height() - barH - d) / 2).coerceAtLeast(0)
        fsBox.layoutParams = lp
        fsLayer.visibility = View.VISIBLE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.insetsController?.let {
            it.hide(WindowInsets.Type.systemBars())
            it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        bmp?.let { fsImg.setImageBitmap(it) }
        refreshLabels()
        if (!live) startLive()
    }

    private fun exitFullscreen() {
        if (!fullscreen) return
        fullscreen = false
        fsLayer.visibility = View.GONE
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.insetsController?.show(WindowInsets.Type.systemBars())
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (fullscreen) exitFullscreen() else super.onBackPressed()
    }

    private fun updateStatus() {
        statusTv.text = if (AdbSession.connected) "Reloj conectado (${AdbSession.peer})" else "Reloj sin conexión"
        if (!AdbSession.connected) {
            stopLive()
            overlay.visibility = View.VISIBLE
            overlay.text = "Sin conexión.\nToca «Conectar»."
        } else if (bmp == null) {
            overlay.visibility = View.VISIBLE
            overlay.text = "Conectado ✓\nToca «Pantalla en vivo»."
        }
    }

    // ---------------------------------------------------------------- conexión

    private fun connectTo(h: String, p: Int, cb: (Boolean, String) -> Unit) {
        AdbSession.connect(h, p) { ok, msg ->
            if (ok) prefs.edit().putString("host", h).putInt("connPort", p).apply()
            cb(ok, if (ok) "Conectado al reloj ✓" else msg)
        }
    }

    private fun autoConnect(cb: (Boolean, String) -> Unit) {
        WatchDiscovery.find(this, WatchDiscovery.TYPE_CONNECT, 5000) { host, port ->
            val h = host ?: (prefs.getString("host", "") ?: "")
            val p = if (host != null) port else prefs.getInt("connPort", 0)
            if (h.isEmpty() || p <= 0) {
                cb(false, "No encuentro el reloj. ¿Depuración inalámbrica activa en el reloj y mismo Wi-Fi?")
            } else {
                connectTo(h, p, cb)
            }
        }
    }

    private fun showConnect() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(8), dp(20), 0)

        val help = TextView(this)
        help.text = "En el RELOJ:\n" +
            "1) Ajustes → Opciones de desarrollador (si no salen: Acerca del reloj → Software y toca 7 veces la versión).\n" +
            "2) Activa «Depuración ADB» y «Depuración inalámbrica». El reloj y el teléfono deben estar en el mismo Wi-Fi.\n" +
            "3) Entra en Depuración inalámbrica → «Vincular nuevo dispositivo»: el reloj muestra IP:puerto y un código.\n\n" +
            "Aquí: pulsa «Buscar reloj (vinculación)», escribe el código y pulsa Vincular. " +
            "Después pulsa «Buscar reloj (conexión)» y Conectar. Si la búsqueda no encuentra nada, escribe IP y puertos a mano."
        help.textSize = 12f
        col.addView(help)

        fun field(hint: String, v: String, number: Boolean): EditText {
            val e = EditText(this)
            e.hint = hint
            if (number) e.inputType = InputType.TYPE_CLASS_NUMBER
            e.setText(v)
            return e
        }

        val ip = field("IP del reloj", prefs.getString("host", "") ?: "", false)
        val pairPort = field("Puerto de vinculación", "", true)
        val code = field("Código de vinculación (6 dígitos)", "", true)
        val connPort = field("Puerto de conexión", if (prefs.getInt("connPort", 0) > 0) prefs.getInt("connPort", 0).toString() else "", true)
        val result = TextView(this)
        result.textSize = 13f
        result.setPadding(0, dp(8), 0, dp(4))

        fun btn(label: String, onClick: () -> Unit): Button {
            val b = Button(this)
            b.text = label
            b.setOnClickListener { onClick() }
            return b
        }

        col.addView(ip)
        col.addView(btn("Buscar reloj (vinculación)") {
            result.text = "Buscando la ventana de vinculación del reloj..."
            WatchDiscovery.find(this, WatchDiscovery.TYPE_PAIRING, 6000) { h, p ->
                runOnUiThread {
                    if (h == null) {
                        result.text = "No lo encuentro. En el reloj abre «Vincular nuevo dispositivo» y vuelve a probar."
                    } else {
                        ip.setText(h)
                        pairPort.setText(p.toString())
                        result.text = "Encontrado: $h:$p. Escribe el código y pulsa Vincular."
                    }
                }
            }
        })
        col.addView(pairPort)
        col.addView(code)
        col.addView(btn("Vincular") {
            val h = ip.text.toString().trim()
            val p = pairPort.text.toString().trim().toIntOrNull()
            val cd = code.text.toString().trim()
            if (h.isEmpty() || p == null || cd.isEmpty()) {
                result.text = "Faltan IP, puerto o código"
            } else {
                result.text = "Vinculando..."
                AdbSession.pair(h, p, cd) { _, msg -> runOnUiThread { result.text = msg } }
            }
        })
        col.addView(btn("Buscar reloj (conexión)") {
            result.text = "Buscando el reloj..."
            WatchDiscovery.find(this, WatchDiscovery.TYPE_CONNECT, 6000) { h, p ->
                runOnUiThread {
                    if (h == null) {
                        result.text = "No lo encuentro. ¿Depuración inalámbrica activa en el reloj?"
                    } else {
                        ip.setText(h)
                        connPort.setText(p.toString())
                        result.text = "Encontrado: $h:$p. Pulsa Conectar."
                    }
                }
            }
        })
        col.addView(connPort)
        col.addView(btn("Conectar") {
            val h = ip.text.toString().trim()
            val p = connPort.text.toString().trim().toIntOrNull()
            if (h.isEmpty() || p == null) {
                result.text = "Faltan IP o puerto de conexión"
            } else {
                result.text = "Conectando..."
                connectTo(h, p) { _, msg -> runOnUiThread { result.text = msg } }
            }
        })
        col.addView(result)

        val sv = ScrollView(this)
        sv.addView(col)
        AlertDialog.Builder(this)
            .setTitle("Conectar con el reloj")
            .setView(sv)
            .setNeutralButton("Desconectar") { _, _ -> AdbSession.disconnect() }
            .setPositiveButton("Cerrar", null)
            .show()
    }

    // ---------------------------------------------------------------- control del reloj

    private fun needConnection(): Boolean {
        if (AdbSession.connected) return true
        toast("Primero conecta el reloj")
        showConnect()
        return false
    }

    private fun key(code: Int) {
        if (!AdbSession.connected) {
            toast("Reloj sin conexión")
            return
        }
        AdbSession.shell("input keyevent $code")
    }

    private fun inject(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long, w: Int, h: Int) {
        if (!AdbSession.connected) return
        fun cx(v: Float): Int = v.toInt().coerceIn(0, w - 1)
        fun cy(v: Float): Int = v.toInt().coerceIn(0, h - 1)
        val dist = hypot(x2 - x1, y2 - y1)
        val cmd = if (dist < 14f) {
            if (dur >= 450L) {
                "input swipe ${cx(x1)} ${cy(y1)} ${cx(x1)} ${cy(y1)} ${dur.coerceAtMost(3000L)}"
            } else {
                "input tap ${cx(x1)} ${cy(y1)}"
            }
        } else {
            "input swipe ${cx(x1)} ${cy(y1)} ${cx(x2)} ${cy(y2)} ${dur.coerceIn(80L, 1500L)}"
        }
        AdbSession.shell(cmd)
    }

    // ---------------------------------------------------------------- pantalla en vivo

    private fun toggleLive() {
        if (live) stopLive() else startLive()
    }

    private fun startLive() {
        if (!needConnection()) return
        live = true
        failures = 0
        lastFrameT = 0L
        fpsAvg = 0f
        liveBtn.text = "Pausar"
        AdbSession.shell("input keyevent 224")
        scheduleFrame()
    }

    private fun stopLive() {
        live = false
        if (::liveBtn.isInitialized) liveBtn.text = "Pantalla en vivo"
    }

    private fun scheduleFrame() {
        if (!live) return
        val t0 = SystemClock.elapsedRealtime()
        AdbSession.exec {
            val out = AdbSession.shellRaw("screencap -p | base64")
            val b: Bitmap? = try {
                val bytes = Base64.decode(out, Base64.DEFAULT)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            } catch (_: Throwable) {
                null
            }
            runOnUiThread {
                val now = SystemClock.elapsedRealtime()
                if (b != null) {
                    failures = 0
                    bmp = b
                    screenImg.setImageBitmap(b)
                    if (::fsImg.isInitialized) fsImg.setImageBitmap(b)
                    overlay.visibility = View.GONE
                    if (lastFrameT != 0L && now > lastFrameT) {
                        val inst = 1000f / (now - lastFrameT)
                        fpsAvg = if (fpsAvg == 0f) inst else fpsAvg * 0.8f + inst * 0.2f
                    }
                    lastFrameT = now
                    val txt = String.format(Locale.US, "Reales: ≈ %.1f fps · objetivo %d", fpsAvg, fps)
                    fpsTv.text = txt
                    if (::fsInfo.isInitialized) fsInfo.text = txt
                } else {
                    failures++
                    AdbSession.log("Fotograma inválido: " + out.take(120))
                    if (failures >= 3) {
                        stopLive()
                        toast("No pude leer la pantalla del reloj. Mira «Registro app».")
                    }
                }
                if (live) {
                    val wait = (1000L / fps - (now - t0)).coerceAtLeast(0L)
                    main.postDelayed({ scheduleFrame() }, wait)
                }
            }
        }
    }

    private fun screenshot() {
        val b = bmp
        if (b == null) {
            toast("Primero activa «Pantalla en vivo»")
            return
        }
        try {
            val out = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            val path = Path()
            path.addCircle(b.width / 2f, b.height / 2f, b.width / 2f, Path.Direction.CW)
            c.clipPath(path)
            c.drawBitmap(b, 0f, 0f, null)
            val values = ContentValues()
            val name = "Reloj-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".png"
            values.put(MediaStore.Images.Media.DISPLAY_NAME, name)
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/RelojRemoto")
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri == null) {
                toast("No se pudo guardar la captura")
                return
            }
            contentResolver.openOutputStream(uri)?.use { os -> out.compress(Bitmap.CompressFormat.PNG, 100, os) }
            toast("Captura guardada en Imágenes/RelojRemoto")
        } catch (t: Throwable) {
            toast("Captura falló: ${t.message}")
        }
    }

    // ---------------------------------------------------------------- instalar APK

    private fun pickApk() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(
            Intent.EXTRA_MIME_TYPES,
            arrayOf("application/vnd.android.package-archive", "application/octet-stream")
        )
        startActivityForResult(i, reqPickApk)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqPickApk && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            installToWatch(uri)
        }
    }

    /** Envía el APK al reloj por trozos y lo instala; método principal + respaldos (ver Installer). */
    private fun installToWatch(uri: Uri) {
        if (!needConnection()) return
        val tv = TextView(this)
        tv.setPadding(dp(20), dp(16), dp(20), dp(16))
        tv.textSize = 13f
        tv.text = "Preparando..."
        val sv = ScrollView(this)
        sv.addView(tv)
        AlertDialog.Builder(this)
            .setTitle("Instalando en el reloj")
            .setView(sv)
            .setPositiveButton("Cerrar", null)
            .show()

        Installer.install(
            this,
            uri,
            say = { s ->
                runOnUiThread {
                    tv.text = s
                    sv.post { sv.fullScroll(View.FOCUS_DOWN) }
                }
            },
            ask = { question, answer ->
                runOnUiThread {
                    AlertDialog.Builder(this)
                        .setTitle("Forzar instalación")
                        .setMessage(question)
                        .setPositiveButton("Desinstalar y reinstalar") { _, _ -> answer(true) }
                        .setNegativeButton("No") { _, _ -> answer(false) }
                        .setOnCancelListener { answer(false) }
                        .show()
                }
            }
        )
    }

    // ---------------------------------------------------------------- apps, info, registros

    private fun showApps() {
        if (!needConnection()) return
        AdbSession.shell("pm list packages -3") { out ->
            val pk = out.split("\n")
                .map { it.trim().removePrefix("package:") }
                .filter { it.isNotEmpty() && !it.contains(" ") }
                .sorted()
            runOnUiThread {
                if (pk.isEmpty()) {
                    toast("No hay apps instaladas por ti en el reloj")
                } else {
                    AlertDialog.Builder(this)
                        .setTitle("Apps instaladas en el reloj")
                        .setItems(pk.toTypedArray()) { _, i -> appActions(pk[i]) }
                        .setNegativeButton("Cerrar", null)
                        .show()
                }
            }
        }
    }

    private fun appActions(pkg: String) {
        val items = arrayOf("Abrir", "Detener", "Borrar datos", "Desinstalar")
        AlertDialog.Builder(this)
            .setTitle(pkg)
            .setItems(items) { _, w ->
                when (w) {
                    0 -> AdbSession.shell("monkey -p $pkg -c android.intent.category.LAUNCHER 1")
                    1 -> AdbSession.shell("am force-stop $pkg")
                    2 -> AdbSession.shell("pm clear $pkg") { toast(it) }
                    3 -> AdbSession.shell("pm uninstall $pkg") { toast(it) }
                    else -> {}
                }
            }
            .show()
    }

    private fun showText(title: String, text: String, refresh: (() -> Unit)?) {
        val tv = TextView(this)
        tv.text = text
        tv.typeface = Typeface.MONOSPACE
        tv.textSize = 11f
        tv.setTextIsSelectable(true)
        tv.setPadding(dp(16), dp(8), dp(16), dp(8))
        val sv = ScrollView(this)
        sv.addView(tv)
        val b = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(sv)
            .setNeutralButton("Copiar") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText(title, text))
                toast("Copiado")
            }
            .setPositiveButton("Cerrar", null)
        if (refresh != null) b.setNegativeButton("Actualizar") { _, _ -> refresh() }
        b.show()
    }

    private fun showInfo() {
        if (!needConnection()) return
        val cmd = "(echo \"Modelo: \$(getprop ro.product.model)\"; " +
            "echo \"Android: \$(getprop ro.build.version.release) (API \$(getprop ro.build.version.sdk))\"; " +
            "echo \"Pantalla: \$(wm size | tail -n 1)\"; " +
            "echo \"Densidad: \$(wm density | tail -n 1)\"; " +
            "echo \"Escala de fuente: \$(settings get system font_scale)\"; " +
            "echo \"Paquetes WebView: \$(pm list packages | grep -c webview)\")"
        AdbSession.shell(cmd) { out -> runOnUiThread { showText("Tu reloj", out, null) } }
    }

    private fun showWatchLog() {
        if (!needConnection()) return
        AdbSession.shell("logcat -d -t 400 '*:W'") { out ->
            runOnUiThread { showText("Registro del reloj (avisos y errores)", out) { showWatchLog() } }
        }
    }

    private fun showLog() {
        showText("Registro de la app", AdbSession.logText(), null)
    }

    private fun toast(s: String) {
        runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }
    }
}

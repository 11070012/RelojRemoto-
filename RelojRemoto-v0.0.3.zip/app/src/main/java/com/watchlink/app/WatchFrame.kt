package com.watchlink.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.SweepGradient
import android.view.MotionEvent
import android.widget.FrameLayout

/**
 * Caja del reloj: dibuja la carcasa redonda y los dos botones laterales del Galaxy Watch5
 * (Inicio arriba, Atrás abajo; no tiene corona). La pantalla va como hijo en el centro.
 */
class WatchFrame(ctx: Context) : FrameLayout(ctx) {
    var onHome: (() -> Unit)? = null
    var onBack: (() -> Unit)? = null

    private val homeRect = RectF()
    private val backRect = RectF()
    private var pressed = 0 // 1 = inicio, 2 = atrás

    private val casePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFF55586A.toInt()
    }
    private val innerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val btnPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    init {
        setWillNotDraw(false)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val s = w.toFloat()
        val cx = s / 2f
        val r = s * 0.45f
        casePaint.shader = SweepGradient(
            cx, h / 2f,
            intArrayOf(0xFF2B2E3B.toInt(), 0xFF8A8FA3.toInt(), 0xFF2B2E3B.toInt(), 0xFF6D7186.toInt(), 0xFF2B2E3B.toInt()),
            null
        )
        rimPaint.strokeWidth = s * 0.006f
        val left = cx + r - s * 0.012f
        val right = cx + r + s * 0.038f
        homeRect.set(left, h * 0.30f, right, h * 0.43f)
        backRect.set(left, h * 0.57f, right, h * 0.70f)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = width * 0.45f
        // Botones (debajo de la carcasa)
        val rad = width * 0.02f
        btnPaint.color = if (pressed == 1) 0xFFB9BDD0.toInt() else 0xFF7D8196.toInt()
        c.drawRoundRect(homeRect, rad, rad, btnPaint)
        btnPaint.color = if (pressed == 2) 0xFFB9BDD0.toInt() else 0xFF7D8196.toInt()
        c.drawRoundRect(backRect, rad, rad, btnPaint)
        // Iconos de los botones
        iconPaint.color = 0xFF14161F.toInt()
        c.drawCircle(homeRect.centerX() + width * 0.004f, homeRect.centerY(), width * 0.011f, iconPaint)
        val tri = Path()
        val tx = backRect.centerX() + width * 0.004f
        val ty = backRect.centerY()
        val t = width * 0.013f
        tri.moveTo(tx - t, ty)
        tri.lineTo(tx + t * 0.7f, ty - t)
        tri.lineTo(tx + t * 0.7f, ty + t)
        tri.close()
        c.drawPath(tri, iconPaint)
        // Carcasa
        c.drawCircle(cx, cy, r, casePaint)
        c.drawCircle(cx, cy, r, rimPaint)
        c.drawCircle(cx, cy, r * 0.935f, innerPaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pressed = when {
                    homeRect.contains(e.x, e.y) -> 1
                    backRect.contains(e.x, e.y) -> 2
                    else -> 0
                }
                invalidate()
                return pressed != 0
            }
            MotionEvent.ACTION_UP -> {
                val was = pressed
                pressed = 0
                invalidate()
                if (was == 1 && homeRect.contains(e.x, e.y)) onHome?.invoke()
                if (was == 2 && backRect.contains(e.x, e.y)) onBack?.invoke()
                return was != 0
            }
            MotionEvent.ACTION_CANCEL -> {
                pressed = 0
                invalidate()
            }
        }
        return pressed != 0
    }
}

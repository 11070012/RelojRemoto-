package com.watchlink.app

import kotlin.math.hypot

/**
 * Convierte lo que haces con el dedo sobre la pantalla redonda en órdenes táctiles para el reloj real:
 * toque, pulsación larga, deslizar y arrastrar.
 *
 * Tres modos (se elige en la app):
 *  - GESTOS: al soltar envía un solo "input tap" o "input swipe" (el más estable).
 *  - SENDEVENT: arrastre en tiempo real escribiendo eventos directamente en el táctil del reloj (rápido, experimental).
 *  - MOTION: arrastre en tiempo real con "input motionevent" (compatible, pero cada orden tarda más).
 */
class TouchPad {
    companion object {
        const val GESTOS = 0
        const val SENDEVENT = 1
        const val MOTION = 2
    }

    @Volatile
    var mode = GESTOS

    var onNote: ((String) -> Unit)? = null

    private var dev: String? = null
    private var maxX = 0
    private var maxY = 0
    private var detected = false
    private var evOk = false
    private var trackId = 1

    private var active = false
    private var dragging = false
    private var sx = 0f
    private var sy = 0f
    private var st = 0L
    private var w = 1
    private var h = 1

    @Volatile
    private var px = 0

    @Volatile
    private var py = 0

    @Volatile
    private var moveQueued = false
    private var lastMoveT = 0L

    private fun cx(v: Float): Int = v.toInt().coerceIn(0, w - 1)
    private fun cy(v: Float): Int = v.toInt().coerceIn(0, h - 1)

    fun down(x: Float, y: Float, t: Long, w: Int, h: Int) {
        active = true
        dragging = false
        sx = x
        sy = y
        st = t
        this.w = w
        this.h = h
        px = cx(x)
        py = cy(y)
        if (mode == SENDEVENT && !detected) {
            detected = true
            AdbSession.execInput { detect() }
        }
    }

    fun move(x: Float, y: Float, t: Long) {
        if (!active) return
        px = cx(x)
        py = cy(y)
        if (mode == GESTOS) return
        if (!dragging) {
            if (hypot(x - sx, y - sy) < 14f) return
            dragging = true
            val x0 = cx(sx)
            val y0 = cy(sy)
            AdbSession.execInput { AdbSession.inputShell(downCmd(x0, y0)) }
        }
        if (!moveQueued && t - lastMoveT >= 30) {
            moveQueued = true
            lastMoveT = t
            AdbSession.execInput {
                try {
                    AdbSession.inputShell(moveCmd(px, py))
                } finally {
                    moveQueued = false
                }
            }
        }
    }

    fun up(x: Float, y: Float, t: Long) {
        if (!active) return
        active = false
        val ex = cx(x)
        val ey = cy(y)
        if (dragging) {
            dragging = false
            AdbSession.execInput { AdbSession.inputShell(upCmd(ex, ey)) }
            return
        }
        val x0 = cx(sx)
        val y0 = cy(sy)
        val dur = t - st
        val dist = hypot(x - sx, y - sy)
        val cmd = if (dist < 14f) {
            if (dur >= 450L) "input swipe $x0 $y0 $x0 $y0 ${dur.coerceAtMost(3000L)}"
            else "input tap $x0 $y0"
        } else {
            "input swipe $x0 $y0 $ex $ey ${dur.coerceIn(80L, 1500L)}"
        }
        AdbSession.execInput { AdbSession.inputShell(cmd) }
    }

    fun cancel() {
        if (dragging) {
            val x = px
            val y = py
            AdbSession.execInput { AdbSession.inputShell(upCmd(x, y)) }
        }
        active = false
        dragging = false
    }

    // ------------------------------------------------------------ órdenes

    private fun useEv() = mode == SENDEVENT && evOk && dev != null

    private fun ev(t: Int, c: Int, v: Int) = "sendevent $dev $t $c $v"

    private fun rawX(x: Int) = (x.toFloat() / (w - 1).coerceAtLeast(1) * maxX).toInt()
    private fun rawY(y: Int) = (y.toFloat() / (h - 1).coerceAtLeast(1) * maxY).toInt()

    private fun downCmd(x: Int, y: Int): String =
        if (useEv()) {
            listOf(ev(3, 57, trackId++), ev(1, 330, 1), ev(3, 53, rawX(x)), ev(3, 54, rawY(y)), ev(0, 0, 0))
                .joinToString(";")
        } else {
            "input touchscreen motionevent DOWN $x $y"
        }

    private fun moveCmd(x: Int, y: Int): String =
        if (useEv()) {
            listOf(ev(3, 53, rawX(x)), ev(3, 54, rawY(y)), ev(0, 0, 0)).joinToString(";")
        } else {
            "input touchscreen motionevent MOVE $x $y"
        }

    private fun upCmd(x: Int, y: Int): String =
        if (useEv()) {
            listOf(ev(3, 57, -1), ev(1, 330, 0), ev(0, 0, 0)).joinToString(";")
        } else {
            "input touchscreen motionevent UP $x $y"
        }

    /** Busca el táctil del reloj (getevent) y comprueba que se puede escribir en él. */
    private fun detect() {
        val out = AdbSession.inputShell("getevent -pl 2>&1")
        var found: String? = null
        var mx = 0
        var my = 0
        for (chunk in out.split("add device")) {
            val path = Regex("/dev/input/event\\d+").find(chunk)?.value ?: continue
            val rx = Regex("ABS_MT_POSITION_X\\s*:\\s*value\\s+-?\\d+,\\s*min\\s+-?\\d+,\\s*max\\s+(\\d+)").find(chunk)
            val ry = Regex("ABS_MT_POSITION_Y\\s*:\\s*value\\s+-?\\d+,\\s*min\\s+-?\\d+,\\s*max\\s+(\\d+)").find(chunk)
            if (rx == null || ry == null) continue
            val direct = chunk.contains("INPUT_PROP_DIRECT")
            if (found == null || direct) {
                found = path
                mx = rx.groupValues[1].toInt()
                my = ry.groupValues[1].toInt()
                if (direct) break
            }
        }
        if (found != null) {
            val w = AdbSession.inputShell("[ -w $found ] && echo W || echo N")
            if (w.contains("W")) {
                dev = found
                maxX = mx
                maxY = my
                evOk = true
                AdbSession.log("Táctil del reloj: $found (máx $mx x $my)")
                return
            }
        }
        evOk = false
        AdbSession.log("sendevent no disponible; se usa input motionevent")
        onNote?.invoke("Este reloj no deja escribir en el táctil; uso «input motionevent»")
    }
}
